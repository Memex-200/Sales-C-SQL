﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;
namespace Sales
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }
        //SqlConnection con = new SqlConnection("Data Source=16.0.1121.4; Initial Catalog=Supermarket1; User Id=sa; Password=951753");
        SqlConnection con = new SqlConnection("Server=MEMEX\\SQLSERVER;Database=Supermarket1;User Id=sa;Password=951753");

        SqlCommand cmd;
        SqlDataAdapter read;
        string sql;


        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void panel2_Paint(object sender, PaintEventArgs e)
        {

        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {
            string pname = txtPName.Text;
            decimal price = decimal.Parse(txtPrice.Text);
            decimal discount = decimal.Parse(txtDis.Text);

            sql = "insert into products(pname,price,discount) values(@pname,@price,@discount)";
            con.Open();
            cmd = new SqlCommand(sql, con);
            cmd.Parameters.AddWithValue("@pname", pname);
            cmd.Parameters.AddWithValue("@price", price);
            cmd.Parameters.AddWithValue("@discount", discount);
            MessageBox.Show("Record Added");
            cmd.ExecuteNonQuery(); // Execute the command
            con.Close();

        }

        private void Form1_Load(object sender, EventArgs e)
        {

        }

        private void button3_Click(object sender, EventArgs e)
        {
            string pID = txtID.Text;
            sql = "select * from products where id = @pID";

            using (SqlConnection con = new SqlConnection("Server=MEMEX\\SQLSERVER;Database=Supermarket1;User Id=sa;Password=951753"))
            {
                using (SqlCommand cmd = new SqlCommand(sql, con))
                {
                    cmd.Parameters.AddWithValue("@pID", pID);

                    con.Open();
                    using (SqlDataReader dr = cmd.ExecuteReader())
                    {
                        if (dr.Read())
                        {
                            txtPName.Text = dr["pname"].ToString();
                            txtPrice.Text = dr["price"].ToString();
                            txtDis.Text = dr["discount"].ToString();
                        }
                        else
                        {
                            MessageBox.Show("Product ID Not Found");
                        }
                    }
                    con.Close();
                }
            }
        }


        private void button2_Click(object sender, EventArgs e)
        {
            string pname = txtPName.Text;
            decimal price = decimal.Parse(txtPrice.Text);
            decimal discount = decimal.Parse(txtDis.Text);
            string pID = txtID.Text;

            sql = "update products set pname = @pname, price = @price, discount = @discount where id = @pID";

            using (SqlConnection con = new SqlConnection("Server=MEMEX\\SQLSERVER;Database=Supermarket1;User Id=sa;Password=951753"))
            {
                using (SqlCommand cmd = new SqlCommand(sql, con))
                {
                    cmd.Parameters.AddWithValue("@pname", pname);
                    cmd.Parameters.AddWithValue("@price", price);
                    cmd.Parameters.AddWithValue("@discount", discount);
                    cmd.Parameters.AddWithValue("@pID", pID);

                    con.Open();
                    cmd.ExecuteNonQuery();
                    con.Close();

                    MessageBox.Show("Record Updated");
                }
            }
        }

        private void button4_Click(object sender, EventArgs e)
        {
            Form3 f3 = new Form3();
            this.Hide();
            f3.Show();
        }
    }
}
