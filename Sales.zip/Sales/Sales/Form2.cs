﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace Sales
{
    public partial class Form2 : Form
    {
        public Form2()
        {
            InitializeComponent();
        }
        //SqlConnection con = new SqlConnection("Data Source=16.0.1121.4; Initial Catalog=Supermarket1; User Id=sa; Password=951753");
        SqlConnection con = new SqlConnection("Server=MEMEX\\SQLSERVER;Database=Supermarket1;User Id=sa;Password=951753");

        SqlCommand cmd;
        SqlDataAdapter read;
        string sql;

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {
            string pID = txtID.Text;
            sql = "select * from products where id = @pID";

            using (SqlConnection con = new SqlConnection("Server=MEMEX\\SQLSERVER;Database=Supermarket1;User Id=sa;Password=951753"))
            {
                using (SqlCommand cmd = new SqlCommand(sql, con))
                {
                    cmd.Parameters.AddWithValue("@pID", pID);

                    con.Open();
                    using (SqlDataReader dr = cmd.ExecuteReader())
                    {
                        if (dr.Read())
                        {
                            txtPName.Text = dr["pname"].ToString();
                            double price= double.Parse(dr["price"].ToString());
                            double discount = double.Parse(dr["discount"].ToString());

                            double cal = price * discount / 100;
                            double discountprice = price - cal;

                            txtPrice.Text = price.ToString();
                            txtDis.Text = discountprice.ToString();
                        }
                        else
                        {
                            MessageBox.Show("Product ID Not Found");
                        }
                    }
                    con.Close();
                }
            }
        }

        private void button1_Click(object sender, EventArgs e)
        {
            string pid = txtID.Text;
            //string pname = txtPName.Text;
            decimal price = decimal.Parse(txtPrice.Text);
            decimal discount = decimal.Parse(txtDis.Text);

            sql = "insert into sales(pid,price,discount) values(@pid,@price,@discount)";
            con.Open();
            cmd = new SqlCommand(sql, con);
            cmd.Parameters.AddWithValue("@pid", pid);
            cmd.Parameters.AddWithValue("@price", price);
            cmd.Parameters.AddWithValue("@discount", discount);
            MessageBox.Show("Record Added");
            cmd.ExecuteNonQuery(); // Execute the command
            con.Close();
        }

        private void button2_Click(object sender, EventArgs e)
        {
            this.Hide();
        }

        private void button3_Click(object sender, EventArgs e)
        {
            Form3 f3 = new Form3();
            this.Hide();
            f3.Show();
        }
    }
}
